﻿![logo.jpg](images/logo.png)

# #

Blog Momentum is a Blog plugin for Umbraco.

The plugin allows you to easily manage blog posts, authors and categories.

This documentation will guide you through how to add/edit/manage your blog posts

Use the navigation tree on the left to look through the documentation categories or simply use the search above.